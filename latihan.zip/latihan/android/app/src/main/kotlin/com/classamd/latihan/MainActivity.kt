package com.classamd.latihan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
