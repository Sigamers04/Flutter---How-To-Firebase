class AppConstant {
  static const String firebaseAppId =
      "1:943199095436:android:8863d18691be6b0019c9a9";
  static const String firebaseApiKey = "";
  static const String firebaseName = "latihan";

  static const String titleApp = "Flutter Firebase";
}
